<%@ page language="java" import="java.util.*" pageEncoding="UTF-8"%>
<%@ include file="/WEB-INF/page/share/taglib.jsp"%>
<%
	String path = request.getContextPath();
	String basePath = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/";
%>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<base href="<%=basePath%>" />
	<title>${title}</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
	<link rel="shortcut icon" href="<%=basePath%>favicon.ico" type="image/x-icon" />
	<link href="res/admin/css/style.css" rel="stylesheet" type="text/css" />
	<script type="text/javascript" src="js/jquery.js"></script>
	<script language="javascript" type="text/javascript" defer="defer"  src="<%=basePath%>datepicker/WdatePicker.js"></script>	
	<link id="artDialogSkin" href="artDialog/skins/default.css" rel="stylesheet" type="text/css" />
	<script type="text/javascript" src="artDialog/artDialog.js"></script>	
	<script type="text/javascript" src="artDialog/plugins/iframeTools.js"></script>
	<script src="js/artDialog.common.js"></script>
	<script src="js/list.common.js"></script>
	<script type="text/javascript">
	</script>
</head>
<body>
	<div class="main">
			<s:form action="mer/lottery/ag!getMemOnline" id="queryFrom" method="post">
			<table width="100%" border="0" cellspacing="5" cellpadding="0">
				<tr>
					<td width="80%" valign="top">
						<div class="wrap">
							<div class="Ld_tw03">
								<div style="clear:both"></div>
								<div class="Ld_tw0302">
									<table border="0" cellspacing="0" cellpadding="0">
										<tr>
											<td width="20">&nbsp;</td>
											<td height="38">&nbsp;登陆账号：</td>
											<td>
												<s:textfield name="redisKey" id="redisKey" cssClass="query_value" theme="simple"/>&nbsp;
											</td>
											<td width="20">&nbsp;</td>
											<td>
												<i class="KbtnS" ><input type="button" id="button2" onclick="topage(1)" value=" 搜 索 " /></i>
											</td>
										</tr>
									</table>
								</div>
							</div>
						</div>
						<table width="100%" border="0" cellspacing="0" cellpadding="0" class="com_doc">
							<tr class="com_doc_h2">
								<th width="10%"><input type="checkbox" name="checkbox" id="checkbox1" onclick="switchAll();" /></th>
								<th width="45%">登陆账号</th>
								<th width="45%">在线状态</th>
							</tr>

							<s:if test="#request.pageView.records!=null&&#request.pageView.records.size>0">
								<s:iterator value="#request.pageView.records" status="status">
								<tr>
									<td><input type="checkbox" name="id" id="id" value="<s:property value="top.key" />"/></td>
									<td><s:property value="top.key" /></td>
									<td><s:property value="top.value.keyType" /></td>
								</tr>
								</s:iterator>
							</s:if>
							<s:else>
								<tr>
									<td colspan="20">没有找到相应的记录</td>
								</tr>
							</s:else>
						</table>
						<table width="100%" border="0" cellspacing="1" cellpadding="1" class="item_page" >
							<tr>
								<td align="left">
								</td>
								<td align="right"><s:property value="pageHTML" escape="false"/></td>
							</tr>
						</table>

					</td>
				</tr>
			</table>
			</s:form>
		</div>
		<br class="Spacer" />
</body>
</html>	
