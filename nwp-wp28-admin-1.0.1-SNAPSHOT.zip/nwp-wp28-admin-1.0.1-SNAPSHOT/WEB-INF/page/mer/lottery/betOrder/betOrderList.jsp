<%@ page language="java" import="java.util.*" pageEncoding="UTF-8"%>
<%@ include file="/WEB-INF/page/share/taglib.jsp"%>
<%
	String path = request.getContextPath();
	String basePath = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/";
%>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<base href="<%=basePath%>" />
	<title>${title}</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
	<link rel="shortcut icon" href="<%=basePath%>favicon.ico" type="image/x-icon" />
	<link href="res/admin/css/style.css" rel="stylesheet" type="text/css" />
	<script type="text/javascript" src="js/jquery.js"></script>
	<script language="javascript" type="text/javascript" defer="defer"  src="<%=basePath%>datepicker/WdatePicker.js"></script>
	<link id="artDialogSkin" href="artDialog/skins/default.css" rel="stylesheet" type="text/css" />
	<script type="text/javascript" src="artDialog/artDialog.js"></script>
	<script type="text/javascript" src="artDialog/plugins/iframeTools.js"></script>
	<script src="js/artDialog.common.js"></script>
	<script src="js/list.common.js"></script>
	<script type="text/javascript">
		$(function() {
			var lotteryType = $.trim($("#lotteryType").val());
			$("#type_"+lotteryType).addClass("hover"); //这个是jquery代码

			 if($("#isAutoFlush").val() == 1){
				 $("#isOpenAutoFlush").attr("checked",true);
				 setTimeout(function(){topage($("#currPage").val());}, 5000);
			 }

			 $("#isOpenAutoFlush").click(function () {
				 if ($(this).is(":checked")) {
					 $("#isAutoFlush").val(1);
					 setTimeout(function(){topage($("#currPage").val());}, 5000);
				 }else{
					 $("#isAutoFlush").val(0);
				 }
			 })

			document.onkeydown = function(e){
			    var ev = document.all ? window.event : e;
			    if(ev.keyCode==13) {
			    	topage(1);
			    }
			}
		});

		function cancelOrder(url){
			var aa = $('[name=id]');
			var ids = '';
		 	for(var i=0;i<aa.length;i++){
		        if(aa[i].checked){
		        	if(ids == '')
		        	 	ids = aa[i].value;
		        	else
		         		ids = ids + "," + aa[i].value;
		       	}
		  	}
		  	if(ids == ''){
		   		alert("请选择批量操作项！");
		   		return ;
		  	}else{
		  		 var params = {
			   		"ids" : ids
		    	};
		  	}
			var actionUrl = url;
		    $.ajax( {
		        url : actionUrl,
		        data : params,
		        dataType : "json",
		        cache : false,
		        type : "POST",
		        error : function(textStatus, errorThrown) {
		    		alert("系统ajax交互错误!");
		        },
		        success : function(data, textStatus) {
		        	alertFun(data.ajaxResult,function(){topage($("#currPage").val());});
		        }
		    });
		}

		function openLottery(url){
			var aa = $('[name=id]');
			var ids = '';
		 	for(var i=0;i<aa.length;i++){
		        if(aa[i].checked){
		        	if(ids == '')
		        	 	ids = aa[i].value;
		        	else
		         		ids = ids + "," + aa[i].value;
		       	}
		  	}
		  	if(ids == ''){
		   		alert("请选择批量操作项！");
		   		return ;
		  	}else{
		  		 var params = {
			   		"ids" : ids
		    	};
		  	}
			var actionUrl = url;
		    $.ajax( {
		        url : actionUrl,
		        data : params,
		        dataType : "json",
		        cache : false,
		        type : "POST",
		        error : function(textStatus, errorThrown) {
		    		alert("系统ajax交互错误!");
		        },
		        success : function(data, textStatus) {
		        	alertFun(data.ajaxResult,function(){topage($("#currPage").val());});
		        }
		    });
		}
	</script>
</head>
<body>
	<div class="main">
		<s:form action="mer/lottery/betOrder!list" id="queryFrom" method="post">
		<s:hidden id="lotteryType" name="lotteryType"/>
		<table width="100%" border="0" cellspacing="5" cellpadding="0">
			<tr>
				<td width="80%" valign="top">
					<div class="wrap">
						<div class="Ld_tw">
							<ul class="Fr Ld_tw02">
								<li><a href="mer/lottery/betOrder!list?lotteryType=0" id="type_0">全部</a></li>
								<%--<s:if test="#session.lotteryTypeList.contains(1)" >
									<li><a href="mer/lottery/betOrder!list?lotteryType=1" id="type_1">北京28</a></li>
								</s:if>--%>

								<s:if test="#session.lotteryTypeList.contains(2)" >
									<li><a href="mer/lottery/betOrder!list?lotteryType=2" id="type_2">加拿大28</a></li>
								</s:if>

								<%--<s:if test="#session.lotteryTypeList.contains(8)" >
									<li><a href="mer/lottery/betOrder!list?lotteryType=8" id="type_8">新加坡28</a></li>
								</s:if>--%>

								<%-- <s:if test="#session.lotteryTypeList.contains(3)" >
									<li><a href="mer/lottery/betOrder!list?lotteryType=3" id="type_3">重庆蛋蛋</a></li>
								</s:if> --%>

								<%--<s:if test="#session.lotteryTypeList.contains(4)" >
									<li><a href="mer/lottery/betOrder!list?lotteryType=4" id="type_4">北京番摊</a></li>
								</s:if>--%>

								<s:if test="#session.lotteryTypeList.contains(5)" >
									<li><a href="mer/lottery/betOrder!list?lotteryType=5" id="type_5">加拿大番摊</a></li>
								</s:if>

								<%-- <s:if test="#session.lotteryTypeList.contains(6)" >
									<li><a href="mer/lottery/betOrder!list?lotteryType=6" id="type_6">时时彩番摊</a></li>
								</s:if> --%>

								<s:if test="#session.lotteryTypeList.contains(7)" >
									<li><a href="mer/lottery/betOrder!list?lotteryType=7" id="type_7">新加坡番摊</a></li>
								</s:if>

								<s:if test="#session.lotteryTypeList.contains(9)" >
									<li><a href="mer/lottery/betOrder!list?lotteryType=9" id="type_9">三公船</a></li>
								</s:if>

								<s:if test="#session.lotteryTypeList.contains(10)" >
									<li><a href="mer/lottery/betOrder!list?lotteryType=10" id="type_10">飞艇番摊</a></li>
								</s:if>
								<s:if test="#session.lotteryTypeList.contains(11)" >
									<li><a href="mer/lottery/betOrder!list?lotteryType=11" id="type_11">加拿大牛牛</a></li>
								</s:if>
								<s:if test="#session.lotteryTypeList.contains(12)" >
									<li><a href="mer/lottery/betOrder!list?lotteryType=12" id="type_12">新加坡牛牛</a></li>
								</s:if>
								<s:if test="#session.lotteryTypeList.contains(13)" >
									<li><a href="mer/lottery/betOrder!list?lotteryType=13" id="type_13">澳洲番摊</a></li>
								</s:if>
								<s:if test="#session.lotteryTypeList.contains(14)" >
									<li><a href="mer/lottery/betOrder!list?lotteryType=14" id="type_14">澳洲幸运28</a></li>
								</s:if>
								<%--<s:if test="#session.lotteryTypeList.contains(15)" >
									<li><a href="mer/lottery/betOrder!list?lotteryType=15" id="type_15">澳洲牛牛</a></li>
								</s:if>--%>

								<s:if test="#session.lotteryTypeList.contains(16)" >
									<li><a href="mer/lottery/betOrder!list?lotteryType=16" id="type_16">香港六合</a></li>
								</s:if>
								<s:if test="#session.lotteryTypeList.contains(17)" >
									<li><a href="mer/lottery/betOrder!list?lotteryType=17" id="type_17">澳门六合</a></li>
								</s:if>

								<s:if test="#session.lotteryTypeList.contains(19)" >
									<li><a href="mer/lottery/betOrder!list?lotteryType=19" id="type_19">极速六合</a></li>
								</s:if>

								<s:if test="#session.lotteryTypeList.contains(20)" >
									<li><a href="mer/lottery/betOrder!list?lotteryType=20" id="type_20">运动会60</a></li>
								</s:if>
								<s:if test="#session.lotteryTypeList.contains(21)" >
									<li><a href="mer/lottery/betOrder!list?lotteryType=21" id="type_21">运动会180</a></li>
								</s:if>
								<s:if test="#session.lotteryTypeList.contains(22)" >
									<li><a href="mer/lottery/betOrder!list?lotteryType=22" id="type_22">皇冠体育</a></li>
								</s:if>
							</ul>
							<br class="Spacer1" />
						</div>
						<div class="Ld_tw03">
							<div class="Ld_tw0302">
								<table border="0" cellspacing="0" cellpadding="0">
									<tr>
										<td height="38">
											&nbsp;&nbsp;代理机构：
										</td>
										<td height="38" width="10">
											<s:select list="promoteGroupList" cssClass="H_binput" style="width: 120px;" listKey="key" listValue="value" id="promoteGroupId" name="promoteGroupId" theme="simple" ></s:select>
										</td>
                                        <td>
											&nbsp;&nbsp;拉手：
                                        </td>
                                        <td width="10">
                                            <s:textfield name="promoterNickName" id="promoterNickName" cssClass="query_value" theme="simple" />
                                        </td>
										<td>
											&nbsp;&nbsp;外部代理：
										</td>
										<td width="10">
											<s:textfield name="foreignAgentNickName" id="foreignAgentNickName" cssClass="query_value" theme="simple" />
										</td>
  										<td height="38">
											&nbsp;&nbsp;房间：
										</td>
										<td height="38"  width="10">
												<s:select list="chatRoomList" cssClass="H_binput" style="width: 130px;"  listKey="key" listValue="value" id="chatroomId" name="chatroomId" theme="simple" ></s:select>
										</td>

										<td height="38">
											&nbsp;&nbsp;时间：
										</td>
										<td height="38" >
											<input name="from" id="from" class="Wdate" style="width: 80px;height: 18px" type="text" value="${from}" onFocus="WdatePicker({skin:'blue',maxDate:'#F{$dp.$D(\'to\')}'})"/>&nbsp;
											<input name="to" id="to" class="Wdate" style="width: 80px;height: 18px" type="text" value="${to}"  onFocus="WdatePicker({skin:'blue',minDate:'#F{$dp.$D(\'from\')}'})"/>
										</td>

									</tr>
									<tr>
										<td height="38">
											&nbsp;&nbsp;期数：
										</td>
										<td height="38"  align="left" width="10">
											<s:textfield name="periods" id="periods" cssClass="query_value" theme="simple" size="10" />
										</td>
										<td height="38">
											&nbsp;&nbsp;昵称：
										</td>
										<td height="38"  align="left" width="10">
											<s:textfield name="nickName" id="nickName" cssClass="query_value" theme="simple" />

										</td>
										<%--<td width="10">&nbsp;</td>
										<td height="38">
											彩票类型：&nbsp;
										</td>
										<td>
											<s:select list="#{-1:'全部',1:'幸运28',2:'加拿大28'}" listKey="key" listValue="value" id="lotteryType" name="lotteryType" theme="simple" ></s:select>&nbsp;
										</td>
										--%>
										<%--<s:if test="lotteryType==22">
											<td height="38">
												&nbsp;&nbsp;体育单号：
											</td>
											<td height="38"  align="left">
												<s:textfield name="wid" id="wid" cssClass="query_value" theme="simple" />
											</td>
										</s:if>--%>

										<td height="38">
											&nbsp;&nbsp;状态：
										</td>
										<td>
											<s:select list="#{0:'全部',1:'待开奖',2:'已开奖',3:'已取消'}" listKey="key" cssStyle="width: 120px;" listValue="value" id="status" name="status" theme="simple" ></s:select>&nbsp;
										</td>
										<td height="38">
											&nbsp;&nbsp;玩家：
										</td>
										<td><s:select list="#{0:'真玩家',1:'假玩家',2:'全部'}" listKey="key" listValue="value" cssStyle="width: 120px;" id="isDummy" name="isDummy" theme="simple" ></s:select>
										</td>

										<td colspan="3">
											&nbsp;&nbsp;<i class="KbtnS" ><input type="button" id="button2" onclick="topage(1)" value="搜 索" /></i>
											&nbsp;<input type="checkbox" id="isOpenAutoFlush"/><em class="B Cl_Red">&nbsp;5秒刷新1次</em>
											<s:hidden name="isAutoFlush" id="isAutoFlush" />
										</td>
									</tr>
								</table>
							</div>
						</div>
					</div>
					<div class="menu">
						<table border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td>
									<a href="javascript:cancelOrder('mer/lottery/betOrder!cancelOrder')" title="批量撤单"><img alt="批量撤单" src="res/admin/images/act/reset.gif" />批量撤单</a>&nbsp;&nbsp;
									<s:if test="lotteryType!=22">
										<a href="javascript:openLottery('mer/lottery/betOrder!openLottery')" title="手动派奖"><img alt="手动派奖" src="res/admin/images/act/act_24.gif" />手动派奖</a>&nbsp;&nbsp;
									</s:if>
									<s:if test="lotteryType==9">
										<a href="javascript:openIframeDialog('投注明细','mer/lottery/gscBetOrder!list','95%','95%')" title="投注明细"><img alt="投注明细" src="res/admin/images/act/act_26.gif" />查看投注明细</a>&nbsp;&nbsp;
									</s:if>
								</td>
							</tr>
						</table>
					</div>
					<div class="Rec">
						<span>玩家总猜猜：<em class="B Cl_Red">${dropMoney}</em>
							&nbsp;&nbsp;玩家总输赢：<em class="B Cl_Red">${profitMoney}</em>
						 </span>
					</div>
					<table width="100%" border="0" cellspacing="0" cellpadding="0" class="com_doc">
						<tr class="com_doc_h2">
							<th width="4%"><input type="checkbox" name="checkbox" id="checkbox1" onclick="switchAll();" /></th>
							<th width="8%">游戏期数</th>
							<th width="7%">游戏昵称</th>
							<!-- <th width="7%">剩余积分</th> -->
							<%--<th width="7%">真假人</th>--%>
							<th width="7%">游戏房间</th>
							<th width="7%">状态</th>
							<th width="12%">猜猜时间</th>
							<th width="*">猜猜内容</th>
							<th width="7%">猜猜积分</th>
							<th width="7%">本轮输赢</th>
							<th width="7%">上轮输赢</th>
							<th width="7%">站点抽水</th>
							<%--<th width="2.5%">真假注</th>--%>
						</tr>

						<s:if test="#request.pageView.records!=null&&#request.pageView.records.size>0">
						    <s:iterator value="#request.pageView.records" status="status" var="o">
						    	<tr>
									<td><input type="checkbox" name="id" id="id" value="<s:property value="id" />"/></td>
									<td><s:property value="lotteryPeriod" /></td>
									<td><s:property value="player.nickName" /></td>
									<%-- <td><fmt:formatNumber value="${o.player.balance}" pattern="#,##0.#" /></td> --%>
									<%--<td><s:if test="player.isDummy==0">真玩</s:if><s:elseif test="player.isDummy==1">假人</s:elseif></td>--%>
									<td><s:property value="chatRoom.title" /></td>
									<td><s:if test="status==1"><em class="B Cl_Red">待开奖</em></s:if><s:elseif test="status==2"><em class="B Cl_Blue">已开奖</em></s:elseif><s:elseif test="status==3"><em class="B Cl_Gray">已取消</em></s:elseif></td>
									<td><s:date name="updateTime" format="yyyy-MM-dd HH:mm:ss"/></td>
									<td><s:property value="betContent" /></td>
									<td><fmt:formatNumber value="${o.dropMoney}" pattern="#,##0.#" /></td>
									<td><fmt:formatNumber value="${o.profitMoney}" pattern="#,##0.#" /></td>
									<td><fmt:formatNumber value="${o.lastWinMoney}" pattern="#,##0.#" /></td>
									<td><fmt:formatNumber value="${o.pumpAmount}" pattern="#,##0.#" /></td>
									<%--<td><s:if test="isDummyOrder==0">真</s:if><s:elseif test="isDummyOrder==1">假</s:elseif></td>--%>
								</tr>
							</s:iterator>
					    </s:if>
					    <s:else>
					    	<tr>
					    		<td colspan="20">没有找到相应的记录</td>
							</tr>
					    </s:else>
					</table>
					<table width="100%" border="0" cellspacing="1" cellpadding="1" class="item_page" >
						<tr>
							<td align="left">
							</td>
							<td align="right"><s:property value="pageHTML" escape="false"/></td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
		</s:form>
	</div>
	<br class="Spacer" />
</body>
</html>
