<%@ page language="java" import="java.util.*" pageEncoding="UTF-8"%>
<%@ include file="/WEB-INF/page/share/taglib.jsp"%>
<%
	String path = request.getContextPath();
	String basePath = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/";
%>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<base href="<%=basePath%>" />
	<title>${system_title}</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
	<link rel="shortcut icon" href="<%=basePath%>favicon.ico" type="image/x-icon" />
	<link href="res/admin/css/style.css" rel="stylesheet" type="text/css" />
	<script type="text/javascript" src="js/jquery.js"></script>
	<script language="javascript" type="text/javascript" defer="defer"  src="<%=basePath%>datepicker/WdatePicker.js"></script>	
	<link id="artDialogSkin" href="artDialog/skins/default.css" rel="stylesheet" type="text/css" />
	<script type="text/javascript" src="artDialog/artDialog.js"></script>	
	<script type="text/javascript" src="artDialog/plugins/iframeTools.js"></script>
	<script src="js/artDialog.common.js"></script>
	<script src="js/list.common.js"></script>
	<script type="text/javascript">
		function changeAll(url,status){
			var aa = $('[name=id]');
			var ids = '';
		 	for(var i=0;i<aa.length;i++){
		        if(aa[i].checked){                             
		        	if(ids == '') 
		        	 	ids = aa[i].value;
		        	else
		         		ids = ids + "," + aa[i].value;
		       	}
		  	}
		  	if(ids == ''){
		   		alert("请选择批量操作项！");
		   		return ;
		  	}else{
		  		 var params = {
			   		"dummy.status" : status,
			   		"ids" : ids
		    	};   
		  	}
			var actionUrl = url;
		    $.ajax( {   
		        url : actionUrl,
		        data : params,   
		        dataType : "json",
		        cache : false, 
		        type : "POST",
		        error : function(textStatus, errorThrown) {   
		    		alert("系统ajax交互错误!");  
		        },   
		        success : function(data, textStatus) {   
		        	alertFun(data.ajaxResult,function(){topage($("#currPage").val());});                
		        }
		    });  
		}
	</script>
</head>
<body> 
	<div class="main">
		<s:form action="mer/baseinfo/dummy!list" id="queryFrom" method="post">
		<table width="100%" border="0" cellspacing="5" cellpadding="0">
			<tr>
				<td width="80%" valign="top">
					<div class="wrap">
						<div class="Ld_tw03">
							<div style="clear:both"></div>
							<div class="Ld_tw0302">
								<table border="0" cellspacing="0" cellpadding="0">
									<tr >
										<td height="38" align="right">
											<s:select list="queryKeyValues" listKey="key" listValue="value" id="queryKey" name="queryKey" theme="simple" ></s:select>&nbsp;
										</td>
										<td>
											<s:textfield name="queryValue" id="queryValue" cssClass="query_value" theme="simple"/>&nbsp;
										</td>
										<td width="10">
											&nbsp;
										</td>
										<td height="38" align="right">
											投注房间：&nbsp;
										</td>
										<td>
											<s:select list="chatRoomList" cssClass="query_value"  listKey="key" listValue="value" id="chatRoomId" headerKey="" headerValue="请选择" name="chatRoomId" theme="simple" ></s:select>&nbsp;
										</td>
										<td width="10">
											&nbsp;
										</td>
										<td>
											<i class="KbtnS" ><input type="submit" id="query" value=" 搜 索 " /></i>
										</td>
									</tr>
								</table>
							</div>
						</div>
					</div>
					<div class="menu">
						<table border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td>
									<a href="javascript:openIframeDialog('所在位置：业务中心&gt;&gt;机器拖号设置&gt;&gt;新增托号','mer/baseinfo/dummy!addUI',800,500)" title="新增托号"><img alt="新增托号" src="res/admin/images/act/add.gif" />新增托号</a>&nbsp;&nbsp;
									<a href="javascript:changeAll('mer/baseinfo/dummy!changeAllStatus',1)" title="批量启用"><img alt="批量启用" src="res/admin/images/act/act_5.gif" />批量开启</a>&nbsp;&nbsp;
									<a href="javascript:changeAll('mer/baseinfo/dummy!changeAllStatus',0)" title="批量关闭"><img alt="批量关闭" src="res/admin/images/act/act_13.gif" />批量关闭</a>&nbsp;&nbsp;
								</td>
							</tr>
						</table>
					</div>
					<table width="100%" border="0" cellspacing="0" cellpadding="0" class="com_doc">
						<tr class="com_doc_h2">
							<th width="5%"><input type="checkbox" name="checkbox" id="checkbox1" onclick="switchAll();" /></th>
							<th width="8%">玩家昵称</th>
							<!-- <th width="8%">剩余积分</th> -->
							<th width="14%">投注房间</th>
							<th width="14%">创建时间</th>
							<th width="8%">启动状态</th>
							<th width="8%">随机投注区间</th>
							<th width="10%">投注期数</th>
							<th width="*">最后发送投注内容</th>
							<th width="8%">相关操作</th>
						</tr>
						
						<s:if test="#request.pageView.records!=null&&#request.pageView.records.size>0">
						    <s:iterator value="#request.pageView.records" status="status" var="objs">
						    	<tr>
						    		<td><input type="checkbox" name="id" id="id" value="<s:property value="id" />"/></td>
						    		<td>
										<s:if test="player.headImg.startsWith('/')">
											<img src="<s:property value="assetsURL" /><s:property value="player.headImg" />"  width="25" height="25"/>
										</s:if>
										<s:else>
											<img src="<s:property value="assetsURL" />/<s:property value="player.headImg" />"  width="25" height="25"/>
										</s:else>
										&nbsp;&nbsp;<s:property value="player.nickName" /></td>
									<%-- <td><fmt:formatNumber value="${objs.player.balance}" pattern="#,##0.#" /></td> --%>
									<td><s:property value="chatRoom.title" />(<s:property value="chatRoom.lotteryTypeResult" />)</td>
									<td><s:date name="createTime" format="yyyy-MM-dd HH:mm:ss" /></td>
									<td><s:if test="status==1"><span class="color_red">开启中</span></s:if><s:elseif test="status==0">已关闭</s:elseif></td>
									<td><s:property value="randomCount" />秒-封盘前</td>
									<td><s:property value="betPeriod" /></td>
									<td><s:property value="betMsg" /></td>
									<td>
										<a href="javascript:openIframeDialog('所在位置：业务中心&gt;&gt;机器拖号设置&gt;&gt;编辑机器托','mer/baseinfo/dummy!editUI?dummy.id=<s:property value="id" />',800,600)" title="修改机器托"><img alt="修改机器托" src="res/admin/images/act/act_7.gif" />修改</a>&nbsp;&nbsp;
										<%--<a href="javascript:openIframeDialog('所在位置：账户信息&gt;&gt;机器拖号设置&gt;&gt;发送信息','mer/baseinfo/dummy!sendMessageUI?dummy.id=<s:property value="id" />',700,250)" title="发送信息"><img alt="发送信息" src="res/admin/images/act/act_26.gif" />发送信息</a>
									--%></td>
								</tr>
							</s:iterator>
					    </s:if>
					    <s:else>
					    	<tr>
					    		<td colspan="20">没有找到相应的记录</td>
							</tr>
					    </s:else>
					</table>
					<table width="100%" border="0" cellspacing="1" cellpadding="1" class="item_page" >
						<tr>
							<td align="left">
							</td>
							<td align="right"><s:property value="pageHTML" escape="false"/></td>
						</tr>
					</table>

				</td>
			</tr>
		</table>
		</s:form>
	</div>
	
	<div class="H_loading_bg" style="display: none"></div>
	<div class="H_loading" style="display: none">
	  <p class="H_loading_txt">数据处理中，请等待...</p>
	  <p><img style="filter:chroma(color=white)" src="res/admin/images/wait.gif"/></p>
	</div>
	<br class="Spacer" />
</body>
</html>	
