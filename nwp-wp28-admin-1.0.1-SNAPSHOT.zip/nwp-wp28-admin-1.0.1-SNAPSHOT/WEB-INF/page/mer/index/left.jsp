<%@ page language="java" import="java.util.*" pageEncoding="UTF-8"%>
<%@ include file="/WEB-INF/page/share/taglib.jsp"%>
<%
	String path = request.getContextPath();
	String basePath = request.getScheme() + "://"+ request.getServerName() + ":" + request.getServerPort()+ path + "/";
%>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<base href="<%=basePath%>" />
		<title>${system_title}</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
		<link rel="shortcut icon" href="<%=basePath%>favicon.ico" type="image/x-icon" />
		<link href="js/jquery/treeview/jquery.treeview.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="js/jquery.js"></script>
		<script type="text/javascript" src="js/jquery/treeview/jquery.treeview.js"></script>
		<script type="text/javascript" src="js/jquery.soChange-min.js"></script>
		<style>
		html,body{width:100%; height:100%;margin: 0px;padding:0;font-size:12px;}
		h2{padding:0px; margin:0px;}
		.left{ width:188px; height:auto;overflow:hidden}
		.left h2{ width:188px; background:#eee; height:34px; line-height:34px; text-align:center; font-size:14px; font-weight:bold; color:#436274; border-bottom:1px solid #ccc}
		a{text-decoration:none; color:#666;font-size:12px;}
		a:hover{text-decoration:none;color:#F60;font-size:12px;}
		</style>

		<script type="text/javascript">
	     	$(function(){
				$("#browser").treeview({
					animated: "fast",
					persist: "location",
					collapsed: false,
					unique: true
				});
			});
		</script>

	</head>
	<body>
		<div class="left">
	     	<h2>系统功能列表</h2>
	    	<div>
			<ul id="browser" class="filetree">
				<li class="opened"><span class="folder">业务中心</span>
					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('彩票期数','mer/lottery/periods!list')" target="main">彩票期数</a></span></li>
					</ul>
					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('房间管理','mer/baseinfo/chatRoom!list')" target="main">房间管理</a></span></li>
					</ul>
					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('玩家管理','mer/baseinfo/player!list?type=1')" target="main">玩家管理</a></span></li>
					</ul>
					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('拉手管理','mer/baseinfo/player!list?type=2')" target="main">拉手管理</a></span></li>
					</ul>
					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('外部代理管理','mer/baseinfo/player!list?type=5')" target="main">外部代理管理</a></span></li>
					</ul>
					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('拖号设置','mer/baseinfo/dummy!list')" target="main">拖号管理</a></span></li>
					</ul>
					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('积分明细','mer/lottery/transRecrd!list')" target="main">积分明细</a></span></li>
					</ul>
					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('玩家竞猜记录','mer/lottery/betOrder!list?lotteryType=0')" target="main">玩家竞猜记录</a></span></li>
					</ul>

					<s:if test="#session.lotteryTypeList.contains(9)" >
						<ul>
							<li><span class="file"><a href="javascript:parent.main.addPanel('三公竞猜明细','mer/lottery/gscBetOrder!list')" target="main">三公竞猜明细</a></span></li>
						</ul>
					</s:if>

					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('查回处理','mer/lottery/up2Down!list')" target="main">查回处理</a></span></li>
					</ul>

					<s:if test="#session.lotteryTypeList.contains(1)||#session.lotteryTypeList.contains(2)||#session.lotteryTypeList.contains(3)||#session.lotteryTypeList.contains(8)||#session.lotteryTypeList.contains(14)" >
						<ul>
							<li><span class="file"><a href="javascript:parent.main.addPanel('PC水钱结算(区分房间)','mer/baseinfo/water!list2')" target="main">PC水钱结算(区分房间)</a></span></li>
						</ul>
						<ul>
							<li><span class="file"><a href="javascript:parent.main.addPanel('PC水钱结算(不分房间)','mer/baseinfo/water!list3')" target="main">PC水钱结算(不分房间)</a></span></li>
						</ul>
					</s:if>

					<s:if test="#session.lotteryTypeList.contains(4)||#session.lotteryTypeList.contains(5)||#session.lotteryTypeList.contains(6)||#session.lotteryTypeList.contains(7)||#session.lotteryTypeList.contains(13)" >
						<ul>
							<li><span class="file"><a href="javascript:parent.main.addPanel('番摊水钱结算(区分房间)','mer/baseinfo/water!list22')" target="main">番摊水钱结算(区分房间)</a></span></li>
						</ul>
						<ul>
							<li><span class="file"><a href="javascript:parent.main.addPanel('番摊水钱结算(不分房间)','mer/baseinfo/water!list33')" target="main">番摊水钱结算(不分房间)</a></span></li>
						</ul>
					</s:if>

					<s:if test="#session.lotteryTypeList.contains(11)||#session.lotteryTypeList.contains(12)" >
						<ul>
							<li><span class="file"><a href="javascript:parent.main.addPanel('牛牛水钱结算(区分房间)','mer/baseinfo/water!listNiuNiu2')" target="main">牛牛水钱结算(区分房间)</a></span></li>
						</ul>
						<ul>
						  <li><span class="file"><a href="javascript:parent.main.addPanel('牛牛水钱结算(不分房间)','mer/baseinfo/water!listNiuNiu3')" target="main">牛牛水钱结算(不分房间)</a></span></li>
						</ul>
					</s:if>
					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('奖金活动','mer/lottery/bonus!list')" target="main">奖金活动</a></span></li>
					</ul>
					<%--<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('回访登记记录','mer/baseinfo/followUp!list')" target="main">回访登记记录</a></span></li>
					</ul>--%>
					<!--<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('手动投注','mer/lottery/manualBet!list')" target="main">手动投注</a></span></li>
					</ul>-->
					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('留言板','mer/baseinfo/messageBoard!list')" target="main">留言板</a></span></li>
					</ul>
				</li>
<%--				<li class="closed"><span class="folder">皇冠体育</span>
					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('体育注单列表','mer/lottery/betOrder!list?lotteryType=22')" target="main">体育注单列表</a></span></li>
					</ul>
					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('体育在线用户','mer/lottery/ag!getMemOnline')" target="main">体育在线用户</a></span></li>
					</ul>
					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('免转钱包流水','mer/lottery/ag!getPlaceBet')" target="main">免转钱包流水</a></span></li>
					</ul>
				</li>--%>
				<li class="closed"><span class="folder">统计汇总</span>
					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('站点每天盈亏','mer/report/dailyProfit!station')" target="main">站点每天盈亏</a></span></li>
					</ul>

					<s:if test="#session.lotteryTypeList.contains(9)" >
						<ul>
							<li><span class="file"><a href="javascript:parent.main.addPanel('三公每天盈亏','mer/report/dailyProfit!sgcStation')" target="main">三公每天盈亏</a></span></li>
						</ul>
					</s:if>

					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('玩家每天盈亏','mer/report/dailyProfit!player')" target="main">玩家每天盈亏</a></span></li>
					</ul>
					<ul>
                                                <li><span class="file"><a href="javascript:parent.main.addPanel('玩家盈亏汇总','spa/finance/wjiaFinance.html')" target="main">玩家盈亏汇总</a></span></li>
                                        </ul>

					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('玩家活动情况','mer/report/playerActivity!index')" target="main">玩家活动情况</a></span></li>
					</ul>
				</li>
				<li class="closed"><span class="folder">财务管理</span>
					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('站点账务明细','spa/finance/stationFinance.html?type=1')" target="main">站点账务明细</a></span></li>
					</ul>
					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('站点每日福利','spa/finance/stationWelfare.html?type=1')" target="main">站点每日福利</a></span></li>
					</ul>
				</li>
				<li class="closed"><span class="folder">基础设置</span>
					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('基础设置','mer/baseinfo/stationInfo!editUI')" target="main">基础设置</a></span></li>
					</ul>
					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('彩种设置','mer/baseinfo/stationLotteryType!list')" target="main">彩种设置</a></span></li>
					</ul>
					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('收款账号','mer/baseinfo/bankCard!list')" target="main">收款账号</a></span></li>
					</ul>

					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('房间类型','mer/baseinfo/chatRoomType!list')" target="main">房间类型</a></span></li>
					</ul>
					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('首页轮播图','mer/baseinfo/advert!list?type=1')" target="main">首页轮播图</a></span></li>
					</ul>
					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('首页公告','mer/baseinfo/advert!list?type=2')" target="main">首页公告</a></span></li>
					</ul>
					<!-- <ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('数据维护','mer/baseinfo/dataMaintain!setUI')" target="main">数据维护</a></span></li>
					</ul> -->

					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('代理机构','mer/baseinfo/promoteGroup!list')" target="main">代理机构</a></span></li>
					</ul>
					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('支付平台','spa/finance/custom.html')" target="main">支付平台</a></span></li>
					</ul>
					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('通道设置','spa/finance/platForm1.html')" target="main">通道设置</a></span></li>
					</ul>
					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('操作日志','spa/finance/wjiaLog.html')" target="main">操作日志</a></span></li>
					</ul>
					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('玩家登陆日志','mer/baseinfo/memUserLog!list')" target="main">玩家登陆日志</a></span></li>
					</ul>
					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('登陆超限凭证','mer/baseinfo/redis!list')" target="main">登陆超限凭证</a></span></li>
					</ul>
					<ul>
						<li><span class="file"><a href="javascript:parent.main.addPanel('IP访问黑名单','mer/baseinfo/ipBlackWhite!list')" target="main">IP访问黑名单</a></span></li>
					</ul>
				</li>
			</ul>
		</div>
	    </div>
	</body>
</html>
